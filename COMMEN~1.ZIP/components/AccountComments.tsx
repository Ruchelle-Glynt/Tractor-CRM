"use client";
import { useState } from "react";

type CommentData = {
  id: string;
  body: string;
  createdAt: string | Date;
  author: { name: string };
};

export default function AccountComments({
  accountId,
  initialComments,
}: {
  accountId: string;
  initialComments: CommentData[];
}) {
  const [comments, setComments] = useState(initialComments);
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setSubmitting(true);
    setError(null);
    const res = await fetch(`/api/accounts/${accountId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ body: text }),
    });
    setSubmitting(false);
    if (!res.ok) {
      const data = await res.json();
      setError(data.error ?? "Something went wrong.");
      return;
    }
    const created = await res.json();
    setComments([created, ...comments]);
    setText("");
  }

  return (
    <section className="mt-10 mb-4">
      <h2 className="text-lg font-semibold text-navy">Comments</h2>
      <p className="mt-1 text-sm text-gray-500">
        Notes on this account - holding expirations, iconic site bookings coming to an end, or anything else worth flagging.
      </p>

      <form onSubmit={handleSubmit} className="mt-3 space-y-2">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          placeholder="e.g. Iconic site on Main Rd booking ends 15 Nov - needs client sign-off to renew"
          className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
        />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={submitting || !text.trim()}
          className="rounded bg-navy px-4 py-2 text-sm text-white disabled:opacity-50"
        >
          {submitting ? "Adding..." : "Add comment"}
        </button>
      </form>

      {comments.length === 0 ? (
        <p className="mt-4 text-sm text-gray-400">No comments yet.</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {comments.map((c) => (
            <li key={c.id} className="rounded border border-gray-200 bg-white px-4 py-3 text-sm">
              <p className="whitespace-pre-wrap">{c.body}</p>
              <p className="mt-2 text-xs text-gray-400">
                {c.author.name} · {new Date(c.createdAt).toLocaleString()}
              </p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
